#include <ros/ros.h>
#include <std_msgs/String.h>
#include <iostream>
#include <std_msgs/Int32.h>
#include <iostream>
#include <string>
#include <geometry_msgs/Pose2D.h>
#include <vector>

#define RATE_HZ 2


using namespace std;

float x;	
float y;
float theta;
geometry_msgs::Pose2D singlePos;
geometry_msgs::Pose2D ballPos;

float xBall;
float yBall;
float thetaBall;

void get_msg(const geometry_msgs::Pose2D& msg) {
	x = msg.x;
	y = msg.y;
	theta = msg.theta;
	singlePos.x = x;
	singlePos.y = y;
	singlePos.theta = theta;
}

void get_ball(const geometry_msgs::Pose2D& mensaje){
	xBall = mensaje.x;
	yBall = mensaje.y;
	thetaBall = mensaje.theta;
	ballPos.x = xBall;
	ballPos.y = yBall;
	ballPos.theta = thetaBall;
}


int main(int argc, char **argv){
	ros::init(argc,argv,"ejemplo_sub_node");
	ros::NodeHandle nh;
	ROS_INFO_STREAM("ejemplo_sub_node initialized");																																							
	ROS_INFO_STREAM(ros::this_node::getName());

	ros::Subscriber sub_vel = nh.subscribe("y_r0", 1000, &get_msg);
	ros::Subscriber meta = nh.subscribe("/ball",1000, &get_ball);
	ros::Rate rate(RATE_HZ);

	//PUBLISHER
	ros::Publisher chatter_pub = nh.advertise<geometry_msgs::Pose2D>("/talker", 1000);
	ros::Publisher chatter_ball = nh.advertise<geometry_msgs::Pose2D>("/talker_ball",1000);


	while (ros::ok()){
		ROS_INFO_STREAM(".");
		cout << "Datos del publicador:" << endl;
		cout<<"X"<<endl;
		cout<<x<<endl;
		ros::spinOnce();
		// ros::spin();
		rate.sleep();


		//PUBLISHER
        std_msgs::String msg;   
        std::stringstream ss;
        //ss << "hello world " << count;
        msg.data = ss.str();

        ROS_INFO("%s", msg.data.c_str());
        chatter_pub.publish(singlePos);
        chatter_ball.publish(ballPos);
	}
    return 0;
}



