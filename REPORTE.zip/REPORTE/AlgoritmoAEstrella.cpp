//Algoritmo A*
//Sirve para la b�squeda de un objeto
//Nos va a permitir llegar a la meta (ball)

public class Nodo
{
#region declaraciones
public Nodo NodoPadre;
public Nodo NodoFinal;
private Vector2 posicion;
public float costoTotal;
public float costoG;
public bool Cerrado = false;
#endregion
 
#region propiedades
public Vector2 Posicion
{
 get
 {
  return posicion;
 }
 set
 {
  posicion = new Vector2((float)MathHelper.Clamp(value.X, 0f, (float)Camara2D.anchoTile * Camara2D.numXTiles),
  (float)MathHelper.Clamp(value.Y, 0f, (float)Camara2D.anchoTile * Camara2D.numYTiles));
 }
}
 
public Int32 GrillaX
{
 get { return (Int32)posicion.X; }
}
 
public Int32 GrillaY
{
 get { return (Int32)posicion.Y; }
}
#endregion
 
public Nodo(Nodo nodoPadre, Nodo nodoFinal, Vector2 posicion, float costo)
{
 NodoPadre = nodoPadre;
 NodoFinal = nodoFinal;
 Posicion = posicion;
 costoG = costo;
 if (nodoFinal != null)
 {
  costoTotal = costoG + Calcularcosto();
 }
}
 
public float Calcularcosto()
{
 return Math.Abs(GrillaX - NodoFinal.GrillaX) + Math.Abs(GrillaY - NodoFinal.GrillaY);
}
 
public Boolean esIgual(Nodo nodo)
{
 return (Posicion == nodo.Posicion);
}
}

public class gestorBusqueda
{
 private const Int32 costoIrDerecho = 10;
 private const Int32 costoIrDiagonal = 15;
 private List<Nodo> listaAbierta = new List<Nodo>();
 private List<Vector2> listaCerrada = new List<Vector2>();
 public TileEngine motor;
 
 public gestorBusqueda(TileEngine motor)
 {
  this.motor = motor;
 }
 

private void adicionarNodoAListaAbierta(Nodo nodo)
{
 Int32 indice = 0;
 float costo = nodo.costoTotal;
 while ((listaAbierta.Count() > indice) &&
 (costo < listaAbierta[indice].costoTotal))
 {
  indice++;
 }
 listaAbierta.Insert(indice, nodo);
}
 
public List<Vector2> encontrarCamino(Vector2 posTileInicial, Vector2 posTileFinal)
{
 if (motor == null)
 {
  return null;
 }
 Tile tileInicial = motor.Mapa.tileMapLayers[0].obtenerTile((int)posTileInicial.X, (int)posTileInicial.Y);
 Tile tileFinal = motor.Mapa.tileMapLayers[0].obtenerTile((int)posTileFinal.X, (int)posTileFinal.Y);
 
 if (tileInicial.Colision || tileFinal.Colision)
 {
  return null;
 }
 
 listaAbierta.Clear();
 listaCerrada.Clear();
 
 Nodo nodoInicial;
 Nodo nodoFinal;
 
 nodoFinal = new Nodo(null, null, posTileFinal, 0);
 nodoInicial = new Nodo(null, nodoFinal, posTileInicial, 0);
 
 // se adiciona el nodo inicial
 adicionarNodoAListaAbierta(nodoInicial);
 while (listaAbierta.Count > 0)
 {
  Nodo nodoActual = listaAbierta[listaAbierta.Count - 1];
  // si es el nodo Final
  if (nodoActual.esIgual(nodoFinal))
  {
   List<Vector2> mejorCamino = new List<Vector2>();
   while (nodoActual != null)
   {
    mejorCamino.Insert(0, nodoActual.Posicion);
    nodoActual = nodoActual.NodoPadre;
   }
  return mejorCamino;
 }
 listaAbierta.Remove(nodoActual);
 
 foreach (Nodo posibleNodo in encontrarNodosAdyacentes(nodoActual, nodoFinal))
 {
  // si el nodo no se encuentra en la lista cerrada
  if (!listaCerrada.Contains(posibleNodo.Posicion))
  {
   // si ya se encuentra en la lista abierta
   if (listaAbierta.Contains(posibleNodo))
   {
    if (posibleNodo.costoG >= posibleNodo.costoTotal)
    {
     continue;
    }
   }
   adicionarNodoAListaAbierta(posibleNodo);
  }
 }
 // se cierra el nodo actual
 listaCerrada.Add(nodoActual.Posicion);
 }
return null;
}
 
private List<Nodo> encontrarNodosAdyacentes(Nodo nodoActual, Nodo nodoFinal)
{
List<Nodo> nodosAdyacentes = new List<Nodo>();
Int32 X = nodoActual.GrillaX;
Int32 Y = nodoActual.GrillaY;
Boolean arribaIzquierda = true;
Boolean arribaDerecha = true;
Boolean abajoIzquierda = true;
Boolean abajoDerecha = true;
 
//Izquierda
if ((X > 0) && (!motor.Mapa.tileMapLayers[0].obtenerTile(X - 1, Y).Colision))
{
 nodosAdyacentes.Add(new Nodo(nodoActual, nodoFinal, new Vector2(X - 1, Y), costoIrDerecho + nodoActual.costoG));
}
else
{
 arribaIzquierda = false;
 abajoIzquierda = false;
}
 
//Derecha
if ((X < motor.Mapa.NumXTiles - 1) && (!motor.Mapa.tileMapLayers[0].obtenerTile(X + 1, Y).Colision))
{
 nodosAdyacentes.Add(new Nodo(nodoActual, nodoFinal,
 new Vector2(X + 1, Y), costoIrDerecho + nodoActual.costoG));
}
else
{
 arribaDerecha = false;
 abajoDerecha = false;
}
 
//Arriba
if ((Y > 0) && (!motor.Mapa.tileMapLayers[0].obtenerTile(X, Y - 1).Colision))
{
 nodosAdyacentes.Add(new Nodo(nodoActual, nodoFinal,
 new Vector2(X, Y - 1), costoIrDerecho + nodoActual.costoG));
}
else
{
 arribaIzquierda = false;
 arribaDerecha = false;
}
 
// Abajo
if ((Y < motor.Mapa.NumYTiles - 1) && (!motor.Mapa.tileMapLayers[0].obtenerTile(X, Y + 1).Colision))
{
 nodosAdyacentes.Add(new Nodo(nodoActual, nodoFinal,
 new Vector2(X, Y + 1), costoIrDerecho + nodoActual.costoG));
}
else
{
 abajoIzquierda = false;
 abajoDerecha = false;
}
 
// Direcci�n Diagonal
if ((arribaIzquierda) && (!motor.Mapa.tileMapLayers[0].obtenerTile(X - 1, Y - 1).Colision))
{
 nodosAdyacentes.Add(new Nodo(nodoActual, nodoFinal,
 new Vector2(X - 1, Y - 1), costoIrDiagonal + nodoActual.costoG));
}
 
if ((arribaDerecha) && (!motor.Mapa.tileMapLayers[0].obtenerTile(X + 1, Y - 1).Colision))
{
 nodosAdyacentes.Add(new Nodo(nodoActual, nodoFinal,
 new Vector2(X + 1, Y - 1), costoIrDiagonal + nodoActual.costoG));
}
 
if ((abajoIzquierda) && (!motor.Mapa.tileMapLayers[0].obtenerTile(X - 1, Y + 1).Colision))
{
 nodosAdyacentes.Add(new Nodo(nodoActual, nodoFinal,
 new Vector2(X - 1, Y + 1), costoIrDiagonal + nodoActual.costoG));
}
 
if ((abajoDerecha) && (!motor.Mapa.tileMapLayers[0].obtenerTile(X + 1, Y + 1).Colision))
{
 nodosAdyacentes.Add(new Nodo(nodoActual, nodoFinal,
 new Vector2(X + 1, Y + 1), costoIrDiagonal + nodoActual.costoG));
}
 
 return nodosAdyacentes;
 }
}



public Color Color { get; set; }
public Tile(Int32 tipo)
{
 Tipo = tipo;
 Colision = false;
 Color = Color.White;
}



//gestorBusqueda GestorBusqueda;
//GestorBusqueda = new gestorBusqueda(mapa);
gestorBusqueda GestorBusqueda;
GestorBusqueda = new gestorBusqueda(mapa);
IsMouseVisible = true;




// C�digo Temporal
MouseState ms = Mouse.GetState();
if ((ms.X > 0) && (ms.Y > 0) &&
 (ms.X < Camara2D.TamanoPantalla.X) && (ms.Y < Camara2D.TamanoPantalla.Y))
 {
  Vector2 mouseLoc = Camara2D.ScreenToWorld(new Vector2(ms.X, ms.Y));
  if (ms.LeftButton == ButtonState.Pressed)
  {
   mouseLoc = mapa.Mapa.GetSquareAtPixel(mouseLoc);
   posTile = mapa.Mapa.GetSquareAtPixel(new Vector2(tanque.Posicion.X + (distancia.X * (tanque.AnchoFrame / 2)),        tanque.Posicion.Y + (distancia.Y * tanque.AltoFrame / 2)) + distancia);
 
   List<Vector2> camino = GestorBusqueda.encontrarCamino(mouseLoc, posTile);
   if (camino != null)
   {
    foreach (Vector2 nodo in camino)
    {
     Tile tile = mapa.Mapa.tileMapLayers[0].obtenerTile((int)nodo.X, (int)nodo.Y);
     tile.Color = new Color(128, 0, 0, 80);
    }
   }
 }
}
// fin codigo temporal

if (debug)
{
 if (tile.Colision)
 {
  tile.Color = Color.Red;
 }
 else
 {
  tile.Color = Color.White;
 }
}
else
{
 if (tile.Color == Color.Transparent)
 {
  tile.Color = Color.White;
 }
}
 
spriteBatch.Draw(layer.sheet.Textura, Vector2.Zero, sourceRect, tile.Color,
0, position, scale, SpriteEffects.None, 0.0f);